#!/bin/bash
# ============================================================
#  Syntra BLQK — personalizzazione eseguita DENTRO il sistema (chroot)
#  (lanciato da build.sh, non eseguirlo a mano sul tuo PC)
# ============================================================
set -Eeuo pipefail
. /etc/syntra/os.conf
. /root/build.env
export DEBIAN_FRONTEND=noninteractive LC_ALL=C LANG=C
APPS=/opt/.syntra-apps
trap 'echo "ERRORE alla riga $LINENO: $BASH_COMMAND"' ERR

say()  { echo; echo "---- $* ----"; }
warn() { echo "ATTENZIONE: $*"; }

# ------------------------------------------------------------
# Protezioni per l'installazione dei pacchetti in un ambiente che NON è un
# sistema avviato (non c'è init, non ci sono servizi in esecuzione):
#  1) policy-rc.d: nessun servizio viene avviato dagli script dei pacchetti
printf '#!/bin/sh\nexit 101\n' > /usr/sbin/policy-rc.d; chmod +x /usr/sbin/policy-rc.d
#  2) update-initramfs sostituito da un comando vuoto (con dpkg-divert, come
#     fanno gli strumenti per le ISO live): l'initramfs si genera una volta
#     sola alla fine, non a ogni pacchetto che lo richiede
DIVERTED="/usr/sbin/update-initramfs"
for f in $DIVERTED; do
  dpkg-divert --quiet --local --rename --divert "$f.syntra-real" --add "$f"
  printf '#!/bin/sh\n# sostituto temporaneo usato durante la build\nexit 0\n' > "$f"; chmod +x "$f"
done
#  3) i comandi che parlano con un init in esecuzione (runit, s6, dinit, ...)
#     qui fallirebbero: durante la build rispondono "ok" senza fare nulla
SHIMS=/usr/local/lib/syntra-build-shims
mkdir -p "$SHIMS"
for c in sv service systemctl dinitctl s6-rc s6-rc-update s6-svc s6-svscanctl initctl telinit; do
  printf '#!/bin/sh\nexit 0\n' > "$SHIMS/$c"; chmod +x "$SHIMS/$c"
done
export PATH="$SHIMS:$PATH"

restore_system_commands() {
  local f
  for f in $DIVERTED; do
    rm -f "$f"
    dpkg-divert --quiet --local --rename --remove "$f" || true
  done
  rm -rf "$SHIMS"
  PATH="${PATH#"$SHIMS":}"
  # script di configurazione disattivati da apt_repair: tornano quelli originali
  for f in /var/lib/dpkg/info/*.syntra-orig; do
    [ -f "$f" ] && mv -f "$f" "${f%.syntra-orig}"
  done
  return 0
}

APT="apt-get -y --no-install-recommends -o Dpkg::Options::=--force-confdef -o Dpkg::Options::=--force-confold -o Acquire::Retries=5 -o Dpkg::Use-Pty=0"
APTLOG=/tmp/syntra-apt.log

apt_try()    { $APT install "$@" 2>&1 | tee "$APTLOG"; return "${PIPESTATUS[0]}"; }
# la causa (in breve) dell'ultimo errore di apt
apt_reason() { grep -E '^(E:|dpkg: error|Err:)' "$APTLOG" 2>/dev/null | head -3 | tr '\n' ' ' | cut -c1-320 || true; }
apt_healthy() { [ -z "$(dpkg --audit 2>/dev/null)" ] && apt-get check >/dev/null 2>&1; }
bad_pkgs() {
  dpkg-query -W -f='${db:Status-Abbrev}|${binary:Package}\n' 2>/dev/null \
    | awk -F'|' '{ s=substr($1,1,2); if (s!="ii" && s!="rc" && s!="un" && s!="hi" && s!="pn") print $2 }'
}
# Se un pacchetto resta "a metà" blocca tutti quelli successivi. Questa funzione
# rimette in ordine: completa le configurazioni e, se lo script di configurazione
# di un pacchetto fallisce (succede fuori da un sistema avviato), lo salta per la
# durata della build e lo segnala nel report.
apt_repair() {
  local p out f round
  dpkg --configure -a >/tmp/syntra-repair.log 2>&1 || true
  $APT -f install >>/tmp/syntra-repair.log 2>&1 || true
  apt_healthy && return 0
  for round in 1 2; do
    for p in $(bad_pkgs); do
      out="$(dpkg --configure "$p" 2>&1)" && continue
      echo "$out" | grep -q 'script subprocess' || continue    # problemi di dipendenze: dopo
      f="/var/lib/dpkg/info/$p.postinst"
      [ -f "$f" ] && [ ! -f "$f.syntra-orig" ] || continue
      cp -p "$f" "$f.syntra-orig"; printf '#!/bin/sh\nexit 0\n' > "$f"
      echo "ATTENZIONE: lo script di configurazione di $p fallisce durante la build ed è stato saltato"
      echo "$out" | grep -vE '^(Setting up|Processing triggers)' | tail -6 | cut -c1-300 | sed "s/^/DETTAGLIO [$p]: /"
      dpkg --configure "$p" >/dev/null 2>&1 || true
    done
    dpkg --configure -a >>/tmp/syntra-repair.log 2>&1 || true
    $APT -f install >>/tmp/syntra-repair.log 2>&1 || true
    apt_healthy && return 0
  done
  return 1
}
apt_fatal() {
  echo "ERRORE: il gestore dei pacchetti è bloccato e non si riesce a sbloccarlo"
  echo "DETTAGLIO [apt]: $(apt_reason)"
  dpkg --audit 2>&1 | head -12 | cut -c1-300 | sed 's/^/DETTAGLIO [dpkg]: /'
  tail -15 /tmp/syntra-repair.log 2>/dev/null | cut -c1-300 | sed 's/^/DETTAGLIO [riparazione]: /'
  exit 1
}

# installa una lista di pacchetti; se uno non esiste non blocca la build
install_pkgs() {
  local p
  apt_try "$@" && return 0
  echo "NOTA: installazione in blocco non riuscita ($(apt_reason)); riprovo un pacchetto alla volta"
  apt_healthy || apt_repair || apt_fatal
  for p in "$@"; do
    apt_try "$p" && continue
    echo "PACCHETTO MANCANTE: $p — $(apt_reason)"
    apt_healthy || apt_repair || apt_fatal
  done
}
# il primo pacchetto installabile di una lista di alternative
install_first() {
  local p
  for p in "$@"; do
    apt-cache show "$p" >/dev/null 2>&1 || continue
    apt_try "$p" && return 0
    apt_healthy || apt_repair || apt_fatal
  done
  echo "PACCHETTO MANCANTE: nessuno tra $*"
}
# segnala le librerie che mancano a un programma
check_libs() {
  local miss
  miss="$(ldd "$1" 2>/dev/null | awk '/not found/{print $1}' | sort -u | tr '\n' ' ' || true)"
  [ -z "$miss" ] || warn "a $(basename "$1") mancano le librerie: $miss"
}
# pacchetti facoltativi: si installano se esistono, senza comparire fra i mancanti
install_optional() {
  local p
  for p in "$@"; do
    apt-cache show "$p" >/dev/null 2>&1 || continue
    apt_try "$p" && continue
    echo "NOTA: pacchetto facoltativo $p non installato ($(apt_reason))"
    apt_healthy || apt_repair || apt_fatal
  done
}
# abilita un servizio per gli init presenti (sysvinit, runit, dinit)
enable_service() {
  local s="$1" d sv n
  [ -x "/etc/init.d/$s" ] && update-rc.d "$s" defaults >/dev/null 2>&1 || true
  for sv in "/etc/sv/$s" "/etc/sv/${s}d" /etc/sv/*"$s"*; do
    [ -d "$sv" ] || continue
    n="$(basename "$sv")"
    for d in /etc/runit/runsvdir/default /etc/service; do
      [ -d "$d" ] && [ ! -e "$d/$n" ] && ln -s "/etc/sv/$n" "$d/$n" || true
    done
    break
  done
  if [ -f "/etc/dinit.d/$s" ] && [ -d /etc/dinit.d/boot.d ] && [ ! -e "/etc/dinit.d/boot.d/$s" ]; then
    ln -s "../$s" "/etc/dinit.d/boot.d/$s" || true
  fi
}

# ------------------------------------------------------------
say "Repository: abilito contrib, non-free e non-free-firmware"
for f in /etc/apt/sources.list /etc/apt/sources.list.d/*.list; do
  [ -f "$f" ] || continue
  sed -i -E '/^deb(-src)? .*debian\.org/{/non-free-firmware/! s/^(deb(-src)? +(\[[^]]*\] +)?[^ ]+ +[^ ]+) .*/\1 main contrib non-free non-free-firmware/}' "$f"
done
for f in /etc/apt/sources.list.d/*.sources; do
  [ -f "$f" ] || continue
  grep -q 'debian.org' "$f" && sed -i -E '/^Components:/{/non-free-firmware/! s/.*/Components: main contrib non-free non-free-firmware/}' "$f"
done

# il kernel resta quello della ISO (deve combaciare con l'initrd della chiavetta)
for p in $(dpkg-query -W -f='${Package}\n' 'linux-image*' 'linux-headers*' 2>/dev/null); do apt-mark hold "$p" >/dev/null || true; done

apt-get update || { sleep 20; apt-get update; } || { sleep 60; apt-get update; }

# configurazione dell'initramfs valida anche fuori da un sistema avviato
mkdir -p /etc/initramfs-tools/conf.d
echo "COMPRESS=gzip" > /etc/initramfs-tools/conf.d/syntra-compress   # gzip: supportato da ogni kernel
echo "MODULES=most"  > /etc/initramfs-tools/conf.d/syntra-modules

# qualche riga di diagnosi che finisce nel report (utile per capire la base)
# (ogni valore è calcolato in modo che un comando mancante non generi errori)
cnt()  { "$@" 2>/dev/null | wc -l || true; }
pkgst() { dpkg-query -W -f='${Status}' "$1" 2>/dev/null | awk '{print $3}' || true; }
INIT_NOW="$(readlink -f /sbin/init 2>/dev/null || true)"
D_S6="$(cnt ls -d /etc/s6 /etc/s6-rc /etc/66)"
D_GETTY="$(ls -d /etc/sv/*tty1* /etc/dinit.d/*tty1* 2>/dev/null | tr '\n' ' ' || true)"
D_SVDIR="$(readlink /etc/service 2>/dev/null || { [ -d /etc/service ] && echo cartella || echo assente; })"
D_HOOKS="$(apt-config dump 2>/dev/null | grep -ciE 'Post-Invoke|Pre-Install-Pkgs' || true)"
echo "DIAGNOSI: init=${INIT_NOW:-?} runit=$([ -d /etc/sv ] && echo si || echo no) sysv=$([ -f /etc/inittab ] && echo si || echo no) dinit=$([ -d /etc/dinit.d ] && echo si || echo no) s6/66=$D_S6 servizi_sv=$(cnt ls /etc/sv) /etc/service=$D_SVDIR"
echo "DIAGNOSI: pacchetti=$(cnt dpkg-query -W -f='x\n') initramfs-tools=$(pkgst initramfs-tools) initrd_in_boot=$(cnt ls /boot/initrd*) connman=$(pkgst connman) console-setup=$(pkgst console-setup)"
echo "DIAGNOSI: hook_apt=$D_HOOKS preferenze_apt=$(cnt ls /etc/apt/preferences /etc/apt/preferences.d/) getty_tty1=${D_GETTY:-nessuno}"
if ! apt_healthy; then
  echo "NOTA: il sistema di base ha già pacchetti da sistemare: $(dpkg --audit 2>&1 | head -3 | tr '\n' ' ' | cut -c1-200)"
  apt_repair || apt_fatal
fi

# ------------------------------------------------------------
say "Grafica: Xorg + Openbox + tint2 + rofi"
install_pkgs \
  xserver-xorg-core xserver-xorg-legacy xserver-xorg-input-libinput xserver-xorg-video-fbdev \
  xinit x11-xserver-utils x11-xkb-utils x11-utils xinput libgl1-mesa-dri \
  dbus dbus-x11 openbox tint2 rofi dunst libnotify-bin feh yad dialog \
  xdg-utils desktop-file-utils shared-mime-info adwaita-icon-theme hicolor-icon-theme \
  fonts-dejavu-core fonts-noto-color-emoji librsvg2-common
install_first fonts-ubuntu fonts-cantarell fonts-noto-core
install_first yaru-theme-gtk arc-theme
install_first yaru-theme-icon papirus-icon-theme

say "App di sistema: file, blocco note, terminale, impostazioni"
install_pkgs pcmanfm mousepad lxterminal lxappearance arandr udevil \
  connman wpasupplicant iw rfkill bluez blueman \
  alsa-utils alsa-ucm-conf \
  sudo locales tzdata keyboard-configuration console-setup psmisc procps \
  curl ca-certificates gnupg xz-utils unzip zstd less nano htop \
  mpv playerctl x11-utils

install_first connman-gtk cmst      # interfaccia per le reti: quella GTK è la più leggera
# antiX distribuisce i servizi di ogni init in pacchetti a parte (runit-service-NOME):
# servono quelli dell'init predefinito, runit
install_optional runit-service-connman runit-service-bluez runit-service-bluetooth runit-service-dbus

say "Firmware e microcodice (Wi-Fi Broadcom SDIO, audio Bay Trail)"
install_pkgs firmware-brcm80211 firmware-intel-sound firmware-misc-nonfree firmware-realtek intel-microcode

say "Strumenti per l'installer (GPT, UEFI 32/64 bit, BIOS)"
install_pkgs parted gdisk dosfstools e2fsprogs rsync squashfs-tools initramfs-tools \
  grub2-common grub-efi-ia32-bin grub-efi-amd64-bin grub-pc-bin efibootmgr
command -v grub-install >/dev/null || warn "grub-install assente: l'installazione su disco non funzionerà"
[ -d /usr/lib/grub/i386-efi ] || warn "GRUB per UEFI a 32 bit assente: l'installazione sul T100T non funzionerà"

say "Librerie per Brave, Falkon, Arduino IDE e FreeLLMAPI"
install_pkgs libdbus-glib-1-2 libnss3 libnspr4 libgbm1 libdrm2 libxss1 libxtst6 libxi6 libxrender1 \
  libxcomposite1 libxdamage1 libxrandr2 libxfixes3 libxshmfence1 libxkbcommon0 libsecret-1-0 libnotify4 \
  libfontconfig1 libfreetype6 libuuid1 libusb-1.0-0 libusb-0.1-4
install_pkgs libxtst6 libxi6
install_first libgtk-3-0t64 libgtk-3-0
install_first libasound2t64 libasound2
install_first libcups2t64 libcups2
install_first libatk-bridge2.0-0t64 libatk-bridge2.0-0
install_first libatspi2.0-0t64 libatspi2.0-0

# ------------------------------------------------------------
BROWSER="${BROWSER:-brave}"
say "Browser predefinito: $BROWSER"
install_brave() {
  command -v curl >/dev/null || return 1
  curl -fsSL https://brave-browser-apt-release.s3.brave.com/brave-browser-archive-keyring.gpg \
       -o /usr/share/keyrings/brave-browser-archive-keyring.gpg || return 1
  cat > /etc/apt/sources.list.d/brave-browser-release.sources <<EOF
Types: deb
URIs: https://brave-browser-apt-release.s3.brave.com/
Suites: stable
Components: main
Architectures: amd64
Signed-By: /usr/share/keyrings/brave-browser-archive-keyring.gpg
EOF
  apt-get update && apt_try brave-browser
}
# Falkon: browser leggero di riserva (sempre presente, dai repository Debian)
install_first falkon epiphany-browser netsurf-gtk
FALK="$(command -v falkon || true)"
[ -n "$FALK" ] && echo "Browser di riserva: $(basename "$FALK")" || warn "nessun browser di riserva leggero installato"

if [ "$BROWSER" = brave ]; then
  if install_brave && command -v brave-browser >/dev/null 2>&1; then
    update-alternatives --install /usr/bin/x-www-browser x-www-browser "$(command -v brave-browser)" 300 >/dev/null 2>&1 || true
    echo "Browser predefinito: Brave"
  elif [ -n "$FALK" ]; then
    warn "Brave non scaricabile ora (lo farà il runner di GitHub): per il momento il predefinito è Falkon"
    update-alternatives --install /usr/bin/x-www-browser x-www-browser "$FALK" 250 >/dev/null 2>&1 || true
  else
    warn "né Brave né Falkon installati"
  fi
elif [ -n "$FALK" ]; then
  update-alternatives --install /usr/bin/x-www-browser x-www-browser "$FALK" 250 >/dev/null 2>&1 || true
fi
# impostazione aziendale di Brave: pagina iniziale e motore di ricerca pronti
if command -v brave-browser >/dev/null 2>&1; then
  mkdir -p /etc/brave/policies/managed
  cat > /etc/brave/policies/managed/syntra.json <<'EOF'
{ "RestoreOnStartup": 1, "HomepageLocation": "https://duckduckgo.com",
  "DefaultSearchProviderEnabled": true, "DefaultSearchProviderName": "DuckDuckGo",
  "DefaultSearchProviderSearchURL": "https://duckduckgo.com/?q={searchTerms}",
  "BackgroundModeEnabled": false, "BraveRewardsDisabled": true, "BraveWalletDisabled": true, "BraveVPNDisabled": true }
EOF
fi

# ------------------------------------------------------------
say "Arduino IDE"
rm -rf /opt/arduino-ide
mv "$APPS/arduino" /opt/arduino-ide
chown -R root:root /opt/arduino-ide
if grep -q legacy /opt/arduino-ide/.syntra-flavor; then
  ARDUINO_BIN=/opt/arduino-ide/arduino
  ARDUINO_ICON=/opt/arduino-ide/lib/icons/256x256/apps/arduino.png
  [ -x /opt/arduino-ide/java/bin/java ] && check_libs /opt/arduino-ide/java/bin/java
else
  ARDUINO_BIN="/opt/arduino-ide/arduino-ide"
  [ -x "$ARDUINO_BIN" ] || ARDUINO_BIN="/opt/arduino-ide/AppRun"
  [ -f /opt/arduino-ide/chrome-sandbox ] && chmod 4755 /opt/arduino-ide/chrome-sandbox
  ARDUINO_ICON="$(find /opt/arduino-ide -maxdepth 3 -name '*.png' -ipath '*arduino*' | sort | tail -1 || true)"
  [ -x /opt/arduino-ide/arduino-ide ] && check_libs /opt/arduino-ide/arduino-ide
fi
cat > /usr/local/bin/arduino-ide <<EOF
#!/bin/bash
# accetta sia percorsi sia URI file:// (dal file manager e dal dock)
args=()
for a in "\$@"; do
  case "\$a" in file://*) a="\${a#file://}"; a="\$(printf '%b' "\${a//%/\\\\x}")" ;; esac
  args+=("\$a")
done
FLAVOR="\$(cat /opt/arduino-ide/.syntra-flavor 2>/dev/null)"
if [ "\$FLAVOR" = legacy ]; then exec "$ARDUINO_BIN" "\${args[@]}"; fi
# Arduino IDE 2.x: limita la memoria del processo Electron sulle macchine da 2 GB
export ELECTRON_ENABLE_LOGGING=0
exec "$ARDUINO_BIN" --js-flags=--max-old-space-size=384 "\${args[@]}"
EOF
chmod +x /usr/local/bin/arduino-ide
if [ -n "${ARDUINO_ICON:-}" ] && [ -f "$ARDUINO_ICON" ]; then cp "$ARDUINO_ICON" /usr/share/pixmaps/syntra-arduino.png
else cp /usr/share/pixmaps/syntra-logo.png /usr/share/pixmaps/syntra-arduino.png; warn "icona di Arduino IDE non trovata"; fi
# le schede Arduino/ESP collegate via USB sono utilizzabili senza essere root
cat > /etc/udev/rules.d/60-syntra-arduino.rules <<'EOF'
SUBSYSTEMS=="usb", ATTRS{idVendor}=="2341", MODE="0666"
SUBSYSTEMS=="usb", ATTRS{idVendor}=="2a03", MODE="0666"
SUBSYSTEMS=="usb", ATTRS{idVendor}=="1a86", MODE="0666"
SUBSYSTEMS=="usb", ATTRS{idVendor}=="10c4", MODE="0666"
SUBSYSTEMS=="usb", ATTRS{idVendor}=="0403", MODE="0666"
KERNEL=="ttyACM[0-9]*", MODE="0666"
KERNEL=="ttyUSB[0-9]*", MODE="0666"
EOF

# ------------------------------------------------------------
say "FreeLLMAPI"
if [ -f "$APPS/freellmapi.deb" ]; then
  # app desktop ufficiale (pacchetto .deb verificato da build.sh)
  if ! apt_try "$APPS/freellmapi.deb"; then
    apt_healthy || apt_repair || true
    warn "installazione di FreeLLMAPI con apt non riuscita: estraggo il pacchetto a mano"
    dpkg-deb -x "$APPS/freellmapi.deb" /
    ln -sf /opt/FreeLLMAPI/freellmapi-desktop /usr/bin/freellmapi-desktop
  fi
  [ -x /opt/FreeLLMAPI/freellmapi-desktop ] || { echo "FreeLLMAPI desktop non installato"; exit 1; }
  # sandbox di Chromium: setuid, così funziona anche se il kernel non permette
  # i "user namespace" agli utenti normali (lo script del pacchetto decide in
  # base al kernel della macchina di build, che non è quello del T100T)
  chown root:root /opt/FreeLLMAPI/chrome-sandbox && chmod 4755 /opt/FreeLLMAPI/chrome-sandbox
  check_libs /opt/FreeLLMAPI/freellmapi-desktop
elif [ -d "$APPS/freellmapi" ]; then
  # solo server: Node.js ufficiale + build di produzione fatta da build.sh
  rm -rf /opt/freellmapi /opt/node
  mv "$APPS/freellmapi" /opt/freellmapi
  mv "$APPS/node" /opt/node
  chown -R root:root /opt/freellmapi /opt/node
  /opt/node/bin/node -e 'process.exit(0)' || { echo "Node.js non funziona nel sistema"; exit 1; }
  echo "FreeLLMAPI server @ $(cat /opt/freellmapi/.syntra-commit 2>/dev/null) con Node $(/opt/node/bin/node -v)"
else
  echo "FreeLLMAPI non trovato tra le app preparate da build.sh"; exit 1
fi

# ------------------------------------------------------------
say "Lingua, tastiera e fuso orario"
if [ -f /etc/locale.gen ]; then
  sed -i -E "s/^# *(${LOCALE//./\\.}.*)/\1/; s/^# *(en_US\.UTF-8.*)/\1/" /etc/locale.gen
  grep -q "^${LOCALE//./\\.}" /etc/locale.gen || echo "$LOCALE UTF-8" >> /etc/locale.gen
else
  printf '%s UTF-8\nen_US.UTF-8 UTF-8\n' "$LOCALE" > /etc/locale.gen
fi
locale-gen
update-locale LANG="$LOCALE" LANGUAGE="${LOCALE%%_*}" 2>/dev/null || echo "LANG=$LOCALE" > /etc/default/locale
cat > /etc/default/keyboard <<EOF
XKBMODEL="pc105"
XKBLAYOUT="$KEYMAP"
XKBVARIANT=""
XKBOPTIONS=""
BACKSPACE="guess"
EOF
sed -i "s/Option \"XkbLayout\" \"[^\"]*\"/Option \"XkbLayout\" \"$KEYMAP\"/" /etc/X11/xorg.conf.d/40-syntra-input.conf
mkdir -p /etc/skel/.config/syntra && echo "$KEYMAP" > /etc/skel/.config/syntra/keyboard
# sfondo predefinito
[ -n "${WALL:-}" ] && echo "$WALL" > /etc/skel/.config/syntra/wallpaper
# modalità del video di avvio
echo "${SPLASH_MODE:-always}" > /etc/skel/.config/syntra/splash
ln -sf "/usr/share/zoneinfo/$TIMEZONE" /etc/localtime; echo "$TIMEZONE" > /etc/timezone

# ------------------------------------------------------------
say "Identità del sistema (rebranding)"
divert() {  # sposta il file originale, così gli aggiornamenti apt non lo ripristinano
  dpkg-divert --quiet --local --rename --add --divert "$1.distrib" "$1" 2>/dev/null || true
}
PRETTY="$OS_NAME $OS_VERSION"
for f in /usr/lib/os-release /etc/lsb-release /etc/issue /etc/issue.net; do divert "$f"; done
rm -f /etc/os-release
cat > /usr/lib/os-release <<EOF
PRETTY_NAME="$PRETTY"
NAME="$OS_NAME"
VERSION_ID="$OS_VERSION"
VERSION="$OS_VERSION ($OS_CODENAME)"
VERSION_CODENAME=$OS_CODENAME
ID=$OS_ID
ID_LIKE=debian
EOF
ln -sf ../usr/lib/os-release /etc/os-release
cat > /etc/lsb-release <<EOF
DISTRIB_ID="$OS_NAME"
DISTRIB_RELEASE=$OS_VERSION
DISTRIB_CODENAME=$OS_CODENAME
DISTRIB_DESCRIPTION="$PRETTY"
EOF
# nella sessione Live il terminale ricorda le credenziali (l'installer le toglie)
printf '%s \\n \\l\n\nSessione Live: utente "%s", password "%s"\n\n' "$PRETTY" "$LIVE_USER" "${LIVE_PASSWORD:-demo}" > /etc/issue
echo "$PRETTY" > /etc/issue.net
: > /etc/motd
echo "$OS_HOSTNAME" > /etc/hostname
cat > /etc/hosts <<EOF
127.0.0.1   localhost
127.0.1.1   $OS_HOSTNAME
::1         localhost ip6-localhost ip6-loopback
EOF
# file di versione usato da vari strumenti per riconoscere la distribuzione
for f in /etc/antix-version /etc/mx-version; do [ -f "$f" ] && echo "$PRETTY" > "$f"; done
find /usr/share/wallpaper /usr/share/backgrounds -maxdepth 1 -iname '*antix*' -delete 2>/dev/null || true
# le note di licenza dei pacchetti (/usr/share/doc/*/copyright) restano dove sono:
# sono richieste dalle licenze del software libero su cui il sistema è costruito.
mkdir -p /usr/share/doc/syntra
cat > /usr/share/doc/syntra/CREDITS <<EOF
$PRETTY è costruito con software libero di molti autori (kernel Linux,
strumenti GNU, Debian e altri). Le licenze e i nomi degli autori di ogni
componente sono in /usr/share/doc/<pacchetto>/copyright.
EOF

# ------------------------------------------------------------
say "Tema blu/nero/bianco: scelgo la variante disponibile"
pick_theme() { for t in "$@"; do [ -d "/usr/share/themes/$t" ] && { echo "$t"; return; }; done; echo "$1"; }
pick_icons() { for t in "$@"; do [ -d "/usr/share/icons/$t" ] && { echo "$t"; return; }; done; echo "$1"; }
GTK_T="$(pick_theme Yaru-blue-dark Yaru-dark Yaru Adwaita-dark)"
ICO_T="$(pick_icons Yaru-blue Yaru Papirus-Dark Adwaita)"
for f in /etc/skel/.config/gtk-3.0/settings.ini /etc/skel/.gtkrc-2.0; do
  [ -f "$f" ] || continue
  sed -i -E "s/(gtk-theme-name=\"?)[^\"\n]*(\"?)/\1$GTK_T\2/; s/(gtk-icon-theme-name=\"?)[^\"\n]*(\"?)/\1$ICO_T\2/" "$f"
done
for f in /etc/skel/.config/rofi/config.rasi /usr/share/syntra/rofi/apps.rasi; do
  [ -f "$f" ] && sed -i "s/icon-theme: \"[^\"]*\"/icon-theme: \"$ICO_T\"/" "$f"
done
[ -f /etc/skel/.config/tint2/dock.tint2rc ] && sed -i "s/^launcher_icon_theme = .*/launcher_icon_theme = $ICO_T/" /etc/skel/.config/tint2/dock.tint2rc
echo "tema GTK: $GTK_T   icone: $ICO_T"

say "Sessione grafica, permessi, servizi"
# senza systemd/logind Xorg ha bisogno dei permessi di root per aprire schermo e tastiera
cat > /etc/X11/Xwrapper.config <<'EOF'
allowed_users=anybody
needs_root_rights=yes
EOF
if [ -e /usr/lib/xorg/Xorg.wrap ]; then
  [ -u /usr/lib/xorg/Xorg.wrap ] || chmod u+s /usr/lib/xorg/Xorg.wrap
elif [ -x /usr/lib/xorg/Xorg ]; then
  # senza il wrapper (pacchetto xserver-xorg-legacy assente) si usa il metodo classico
  chmod u+s /usr/lib/xorg/Xorg; warn "Xorg.wrap assente: reso setuid direttamente /usr/lib/xorg/Xorg"
else
  warn "Xorg non trovato in /usr/lib/xorg: la grafica non partirà"
fi
update-alternatives --set x-terminal-emulator /usr/bin/lxterminal 2>/dev/null || true
chown root:root /etc/sudoers.d/syntra* && chmod 0440 /etc/sudoers.d/syntra*
for f in /etc/sudoers.d/syntra*; do visudo -cf "$f"; done
chmod 0755 /usr/local/bin/* /usr/local/sbin/*

for s in dbus connman bluetooth; do enable_service "$s"; done
mkdir -p /etc/connman
cat > /etc/connman/main.conf <<'EOF'
[General]
PreferredTechnologies=wifi,ethernet
SingleConnectedTechnology=false
AllowHostnameUpdates=false
# evita cadute/cicli del Wi-Fi: niente scansioni continue in background
BackgroundScanning=false
# il controllo "sei online?" di connman può far ciclare la connessione: disattivato
EnableOnlineCheck=false
OnlineCheckMode=none
# mantieni la rete anche se la verifica internet non riesce
AlwaysConnectedTechnologies=wifi,ethernet
EOF

# IMPORTANTE: il proxy DNS interno di connman lascia spesso /etc/resolv.conf
# puntato al loopback (nameserver ::1 / 127.0.0.1) e, siccome l'init.d collega
# /etc/resolv.conf -> /run/connman/resolv.conf, la risoluzione DNS muore:
# niente navigazione, Store "pacchetto non trovato", browser che non cerca.
# FIX PRINCIPALE E STABILE: l'init.d di connman fa ". /etc/default/connman" e
# passa $DAEMON_OPTS dopo il "--" a connmand. Creo quel file con --nodnsproxy
# così connman scrive i DNS REALI della rete (niente loopback), su qualsiasi
# versione, senza dipendere da sed fragili sulla riga di avvio.
mkdir -p /etc/default
cat > /etc/default/connman <<'EOF'
# Syntra: disattiva il proxy DNS interno di connman.
# Con --nodnsproxy connman NON mette "nameserver ::1/127.0.0.1" in resolv.conf,
# ma scrive i DNS forniti via DHCP dalla rete -> la risoluzione funziona.
DAEMON_OPTS="--nodnsproxy"
EOF
echo "connman: /etc/default/connman creato (DAEMON_OPTS=--nodnsproxy)"

# In più (cintura e bretelle) applico --nodnsproxy anche agli altri modi in cui
# connman può partire (runit, dinit, s6, 66), per le varianti che non leggono
# /etc/default/connman.
add_nodnsproxy() {  # $1 = file che lancia connmand
  [ -f "$1" ] || return 0
  grep -q -- '--nodnsproxy' "$1" && return 0
  # init.d Debian: start-stop-daemon --exec $DAEMON -- $DAEMON_OPTS
  if grep -qE 'start-stop-daemon.*--exec' "$1" && grep -qE '[$]DAEMON|connmand' "$1"; then
    sed -i -E 's#(start-stop-daemon .*--exec [^\n]*) -- #\1 -- --nodnsproxy #' "$1"
  fi
  # runit/dinit/s6/66: riga che lancia direttamente connmand
  sed -i -E 's#(^|[[:space:]])(/usr/sbin/|/usr/bin/)?connmand([[:space:]]|$)#\1\2connmand --nodnsproxy\3#' "$1"
  grep -q -- '--nodnsproxy' "$1" && echo "connman: --nodnsproxy applicato a $1"
}
for f in /etc/sv/connman/run /etc/sv/connmand/run /etc/runit/runsvdir/*/connman/run          /etc/dinit.d/connman /etc/init.d/connman /etc/s6/sv/connman/run /etc/66/*/connman* ; do
  add_nodnsproxy "$f"
done
# se nessun servizio lo lancia, lo avvierà syntra-hwsetup (già con --nodnsproxy)

# risolutore iniziale: DNS pubblici finché connman non fornisce i suoi
# (connman con --nodnsproxy sovrascrive con i DNS della rete una volta connesso)
if [ -L /etc/resolv.conf ] || [ ! -s /etc/resolv.conf ]; then
  rm -f /etc/resolv.conf
  printf 'nameserver 1.1.1.1
nameserver 9.9.9.9
nameserver 8.8.8.8
' > /etc/resolv.conf
fi

# ------------------------------------------------------------
say "Kernel e initramfs per il sistema installato"
# da qui in poi non si installano più pacchetti: tornano i comandi veri
apt_healthy || apt_repair || warn "restano pacchetti non configurati: $(bad_pkgs | tr '\n' ' ')"
restore_system_commands
KVER="${KVER:-}"
[ -n "$KVER" ] && [ -d "/lib/modules/$KVER" ] || KVER="$(ls /lib/modules | sort -V | tail -1)"
# Un initramfs generico (MODULES=most) pronto all'uso: l'installer prova a
# rigenerarlo sul computer di destinazione, ma se non ci riesce il sistema
# installato parte comunque con questo.
if [ ! -f "/boot/vmlinuz-$KVER" ]; then
  warn "kernel /boot/vmlinuz-$KVER assente: initramfs non generato"
elif ! command -v update-initramfs >/dev/null 2>&1; then
  warn "initramfs-tools non installato: il sistema installato non potrebbe avviarsi"
else
  if [ -f "/boot/initrd.img-$KVER" ]; then IMODE=-u; else IMODE=-c; fi
  if ! update-initramfs "$IMODE" -k "$KVER" > /tmp/syntra-initramfs.log 2>&1; then
    warn "initramfs non generato in fase di build (ci riproverà l'installer)"
    tail -6 /tmp/syntra-initramfs.log | cut -c1-300 | sed 's/^/DETTAGLIO [initramfs]: /'
  fi
fi
ls -la /boot | grep -E 'vmlinuz|initrd' || warn "nessun kernel in /boot"

# ------------------------------------------------------------
say "Utente live ($LIVE_USER) e accesso automatico"
if ! id "$LIVE_USER" >/dev/null 2>&1; then
  useradd -m -s /bin/bash "$LIVE_USER"
fi
echo "$LIVE_USER:${LIVE_PASSWORD:-demo}" | chpasswd
for g in sudo audio video netdev bluetooth plugdev dialout lp users input storage; do
  getent group "$g" >/dev/null && usermod -aG "$g" "$LIVE_USER"
done
mkdir -p "/home/$LIVE_USER"
cp -rT /etc/skel "/home/$LIVE_USER"
chown -R "$LIVE_USER:" "/home/$LIVE_USER"
if /usr/local/sbin/syntra-autologin --setup; then
  /usr/local/sbin/syntra-autologin "$LIVE_USER"
else
  warn "accesso automatico non configurato: all'avvio comparirà il login testuale (utente $LIVE_USER); la grafica parte subito dopo"
fi

# ------------------------------------------------------------
say "Menu applicazioni: mostra SOLO le app di Syntra"
mkdir -p /usr/local/share/applications
for f in /usr/share/applications/*.desktop; do
  b="$(basename "$f")"
  case "$b" in syntra-*.desktop) continue ;; esac
  { sed '/^NoDisplay=/d' "$f"; } | awk '/^\[Desktop Entry\]/{print; print "NoDisplay=true"; next} {print}' \
    > "/usr/local/share/applications/$b"
done
update-desktop-database -q /usr/share/applications 2>/dev/null || true
gtk-update-icon-cache -q -f /usr/share/icons/hicolor 2>/dev/null || true

# ------------------------------------------------------------
say "Controlli finali"
# senza questi il sistema non sarebbe utilizzabile: meglio fermare la build
MISSING=""
for c in Xorg startx openbox tint2 rofi dialog rsync parted mkfs.vfat mkfs.ext4 grub-install sudo; do
  command -v "$c" >/dev/null 2>&1 || [ -x "/usr/sbin/$c" ] || [ -x "/usr/lib/xorg/$c" ] || MISSING="$MISSING $c"
done
if [ -n "$MISSING" ]; then
  echo "ERRORE: mancano programmi indispensabili:$MISSING (vedi i PACCHETTO MANCANTE qui sopra)"
  exit 1
fi
[ -d /usr/lib/grub/i386-efi ] || { echo "ERRORE: manca GRUB per UEFI a 32 bit (grub-efi-ia32-bin): il T100T non potrebbe avviarsi dopo l'installazione"; exit 1; }
# questi invece sono solo segnalati
for c in pcmanfm mousepad lxterminal yad feh dbus-launch connmand wpa_supplicant bluetoothd alsamixer iw mpv ksuperkey syntra-store; do
  command -v "$c" >/dev/null 2>&1 || [ -x "/usr/sbin/$c" ] || [ -x "/usr/libexec/bluetooth/$c" ] || [ -x "/usr/lib/bluetooth/$c" ] || warn "comando mancante: $c"
done
command -v brave-browser >/dev/null || command -v falkon >/dev/null || warn "nessun browser installato (Brave/Falkon)"
REST="$(bad_pkgs | tr '\n' ' ')"
[ -z "$REST" ] || warn "pacchetti rimasti non configurati: $REST"

say "Pulizia"
rm -f /usr/sbin/policy-rc.d
apt-get clean
rm -rf /var/lib/apt/lists/* /var/cache/apt/*.bin /var/log/apt/* /tmp/* /root/.cache /root/.npm
rm -f /var/lib/dbus/machine-id
[ -f /etc/machine-id ] && : > /etc/machine-id
find /var/log -type f -exec truncate -s 0 {} + 2>/dev/null || true
echo "chroot-setup completato"
