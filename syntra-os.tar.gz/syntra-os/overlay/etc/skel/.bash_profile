# Syntra: carica le impostazioni della shell e avvia la grafica sul primo terminale
if [ -f ~/.profile ]; then . ~/.profile; elif [ -f ~/.bashrc ]; then . ~/.bashrc; fi
if [ -z "${DISPLAY:-}" ] && [ "$(tty)" = /dev/tty1 ] && ! grep -qw syntra.nox /proc/cmdline; then
  mkdir -p ~/.local/share
  startx -- -nolisten tcp vt1 >~/.local/share/xsession.log 2>&1
  # se si esce dalla sessione (o la grafica non parte) resta il terminale
  echo; echo "Sessione grafica terminata. Scrivi 'startx' per riavviarla."
fi
