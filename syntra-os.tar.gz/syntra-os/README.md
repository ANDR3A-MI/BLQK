# Syntra BLQK

Sistema operativo leggerissimo per **Asus Transformer Book T100T** (Intel Atom Bay Trail, 2 GB di RAM, 32 GB eMMC), costruito su **antiX 26.1 core** (Debian 13, senza systemd) e ribrandizzato.

La ISO si crea **da sola su GitHub** (GitHub Actions): non serve Linux sul tuo PC.

| | |
|---|---|
| **App incluse (e solo queste)** | Pale Moon · FreeLLMAPI · Arduino IDE · Impostazioni (Wi-Fi, Bluetooth, audio, luminosità, schermo, tastiera…) · File · Blocco note · Terminale |
| **Interfaccia** | Openbox + tint2 + rofi, in stile Ubuntu: barra in alto con "Attività", orologio e indicatori; dock a sinistra; griglia delle app |
| **RAM a riposo** | circa 270 MB con il desktop avviato, misurati in macchina virtuale (di cui ~100 MB sono del server grafico senza accelerazione: sul tablet vero ne servono meno). Swap compresso in RAM (zram) attivo |
| **Avvio dalla chiavetta** | menu con **Avvia Live** · **Installa sul disco** · modalità compatibilità · solo terminale |
| **Boot** | BIOS, UEFI a 64 bit **e UEFI a 32 bit** (il T100T ha un firmware a 32 bit su CPU a 64 bit) |

---

## 1. Crea la ISO su GitHub

1. Crea un nuovo repository **pubblico** su GitHub, per esempio `syntra-os`. (Con l'account gratuito i repository privati hanno solo 500 MB di spazio per gli artefatti: la ISO è più grande e il caricamento finale fallirebbe. Nei repository pubblici GitHub Actions è gratuito e senza questo limite.)
2. Nel repository bastano **due file**:
   - `syntra-os.tar.gz` nella cartella principale (*Add file → Upload files*): contiene tutto questo progetto;
   - `.github/workflows/build-iso.yml` (*Add file → Create new file*, scrivi quel percorso come nome e incolla il contenuto del file).

   Il workflow estrae l'archivio da solo. In alternativa puoi caricare tutti i file sciolti mantenendo la struttura delle cartelle: funziona allo stesso modo.
3. Vai su **Actions → "Crea ISO Syntra" → Run workflow**. La build dura circa 30–60 minuti.
4. A fine build apri l'esecuzione e scarica l'artefatto **syntra-iso** (contiene `syntra-1.0-x64.iso`, il checksum e `build-report.txt`).
5. Per una release pubblica con la ISO allegata: crea un tag, es. `git tag v1.0 && git push --tags`.

> Leggi sempre `build-report.txt` (compare anche nel riepilogo dell'esecuzione): elenca eventuali pacchetti non trovati. Se la build si ferma, scarica l'artefatto **syntra-log**: `chroot.log` dice esattamente dove.

## 2. Scrivi la chiavetta

- **balenaEtcher** (consigliato), oppure
- **Rufus**: va bene sia "modalità immagine DD" sia "modalità ISO" (la ISO contiene i loader EFI anche come file), oppure
- da Linux: `sudo dd if=syntra-1.0-x64.iso of=/dev/sdX bs=4M status=progress oflag=sync`.

## 3. Avvia il T100T dalla chiavetta

1. Spegni il tablet e collega la chiavetta (alla dock con tastiera, o con un adattatore OTG).
2. Accendi tenendo premuto **F2** (o **Esc**) per entrare nel BIOS.
3. **Security → Secure Boot → Disabled** (il boot loader non è firmato).
4. **Save & Exit → Boot Override** → scegli la chiavetta USB.
5. Nel menu scegli **Avvia Syntra BLQK (Live)** per provarlo, oppure **Installa Syntra BLQK sul disco**.

Utente della sessione Live: `demo` / password `demo`.

## 4. Installazione

L'installer (a finestre di testo, in italiano) chiede disco, nome, utente, password e accesso automatico, poi:

- crea una tabella **GPT** con partizione EFI (512 MB) + sistema ext4;
- copia il sistema dalla chiavetta;
- installa **GRUB i386-efi** sul T100T, x86_64-efi sugli altri PC UEFI, i386-pc sui PC con BIOS;
- scrive il loader nel percorso standard `EFI/BOOT/BOOTIA32.EFI`, che il firmware del T100T trova sempre (anche senza voce NVRAM).

⚠️ **Il disco scelto viene cancellato completamente** (Windows compreso). Il dual-boot non è previsto in questa versione.

---

## Cosa è stato fatto per il T100T

| Componente | Soluzione |
|---|---|
| UEFI a 32 bit | ISO con `bootia32.efi`; l'installer riconosce il firmware (anche tramite il parametro `syntra.fw` passato da GRUB) e usa `--target=i386-efi` |
| CPU senza AVX | Pale Moon in versione **SSE2** (i pacchetti ufficiali richiedono AVX e sull'Atom non partirebbero) |
| Wi-Fi Broadcom 43241 (SDIO) | `firmware-brcm80211`; se serve, `syntra-hwsetup` estrae la NVRAM dalla variabile EFI e ricarica il driver |
| Audio (bytcr-rt5640) | `firmware-intel-sound` + `alsa-ucm-conf`; all'avvio `syntra-hwsetup` sceglie la scheda giusta (sul T100T la prima è l'HDMI), applica il profilo **HiFi/Speaker** e crea un volume generale software |
| 2 GB di RAM | zram (75% della RAM), nessun compositor, indicatori di rete e volume disegnati dalla barra stessa (nessuna applet residente), FreeLLMAPI e Arduino avviati solo su richiesta |
| Schermo 1366×768 + touch | tap-to-click, Pale Moon con scorrimento XInput2, pulsanti grandi |
| Blocchi casuali Bay Trail | voce di boot "modalità compatibilità" (`intel_idle.max_cstate=1`); se installi partendo da lì, l'opzione resta anche nel sistema installato |
| Luminosità | tasti Fn e cursore in Impostazioni (script proprio, nessuna dipendenza) |

**Bluetooth:** il chip del T100T (BCM4324B3) richiede un firmware che non è distribuibile liberamente. Se ti serve, copia `BCM4324B3.hcd` (si trova nella partizione Windows del tablet, in `C:\Windows\System32\drivers`, con un nome tipo `BCM4324B3_*.hcd`) in `overlay/usr/lib/firmware/brcm/BCM4324B3.hcd` prima di lanciare la build.

## Le app

- **Pale Moon** — build SSE2/GTK3 dal repository Debian indicato da palemoon.org tra le *contributed builds* (kannegieser.net). Si aggiorna con il resto del sistema.
- **FreeLLMAPI** — l'**app desktop ufficiale per Linux** (la stessa di `FreeLLMAPI.exe` per Windows), scaricata dalla pagina Releases del progetto e verificata con l'hash SHA-512 pubblicato. Clic sull'icona: avvia il router locale (`http://127.0.0.1:31415/v1`) e apre la dashboard; l'icona nella barra in alto resta finché non lo chiudi. Usa circa 220 MB di RAM quando è aperta: chiudila dall'icona (*Quit*) o con `syntra-freellmapi --stop` quando non serve. In `config.env` c'è anche la variante `FREELLMAPI_MODE="server"` (solo server, ~100 MB, dashboard nel browser).
- **Arduino IDE** — versione **1.8.19** (Java incluso, archivio ufficiale verificato con il suo checksum): è quella adatta a 2 GB di RAM. L'utente può già usare le porte seriali USB. Per la 2.x (molto più pesante) metti `ARDUINO_IDE="2"` in `config.env` o sceglila quando avvii il workflow.
- **Impostazioni** (Super+I) — Wi-Fi e rete, Bluetooth, audio, luminosità, schermo, aspetto, sfondo, tastiera, data e ora, batteria, aggiornamenti, informazioni.
- **File** (pcmanfm, chiavette montate in automatico), **Blocco note** (mousepad), **Terminale** (lxterminal).

Scorciatoie: **Super+A** o **Super+Spazio** app · **Super+E** file · **Ctrl+Alt+T** terminale · **Super+←/→** affianca finestre · **Alt+F4** chiudi.

## Personalizzare

Tutto è in `config.env` (nome, versione, lingua, versione di antiX, Arduino, FreeLLMAPI). I file dell'interfaccia sono in `overlay/` (copiati così come sono nel sistema), la grafica in `branding/`.

```
.github/workflows/build-iso.yml   la build su GitHub
build.sh                          scarica antiX, personalizza, ricrea la ISO
scripts/chroot-setup.sh           pacchetti, app, rebranding (dentro il sistema)
config.env                        impostazioni della build
branding/                         logo, sfondo, tema del menu di avvio, icone
overlay/                          file copiati nel sistema
  usr/local/sbin/syntra-installer   installer
  usr/local/sbin/syntra-hwsetup     zram, Wi-Fi T100T, audio, servizi
  usr/local/sbin/syntra-getty       accesso automatico (qualunque init)
  usr/local/bin/syntra-*            impostazioni, alimentazione, FreeLLMAPI…
  etc/skel/.config/                 Openbox, tint2, rofi, GTK, dunst
```

## Cosa è stato provato (e cosa no)

Provato in macchina virtuale (QEMU con firmware UEFI a 32 bit, CPU a 64 bit, 2 GB di RAM, disco eMMC emulato), usando il vero `build.sh` su una base di prova con la stessa struttura di una ISO antiX:

- la build completa, dall'estrazione della ISO alla ISO finale;
- avvio della chiavetta con BIOS, UEFI 64 bit, **UEFI 32 bit** (sia scritta in modalità DD, sia copiata su FAT32);
- accesso automatico, avvio del desktop senza systemd/logind, barra, dock, indicatore di rete;
- l'installer dall'inizio alla fine su disco eMMC e il riavvio del sistema installato con UEFI a 32 bit;
- l'app FreeLLMAPI lanciata dalla griglia delle app nel sistema installato (icona nella barra, dashboard in finestra) e, a parte, il server compilato dai sorgenti;
- indicatori di rete e volume, volume software, menu Impostazioni e spegnimento.

**Non** è stato possibile provare (i siti non erano raggiungibili dall'ambiente di sviluppo, da GitHub lo sono):

- la build sulla **vera ISO antiX 26.1** e sui suoi repository: la prima esecuzione su GitHub può richiedere qualche ritocco (nomi di pacchetti, servizi). `build-report.txt` e `chroot.log` dicono cosa;
- **Pale Moon** e **Arduino IDE** veri (nelle prove sono stati sostituiti da segnaposto);
- l'**hardware reale** del T100T: Wi-Fi, audio, touchscreen, luminosità, sospensione.

## Limiti da conoscere

- **"Non riconoscibile" fin dove è possibile.** Tutto ciò che l'utente vede dice Syntra: menu di avvio, desktop, installer, `/etc/os-release`, nome del computer. Un occhio tecnico può comunque risalire alla base: nome del kernel (`uname -r`), messaggi dei primi secondi di avvio della chiavetta, cartella `/antiX` sulla chiavetta (il sistema live la cerca con quel nome), repository apt da cui arrivano gli aggiornamenti. Le note di licenza dei pacchetti (`/usr/share/doc/*/copyright`) restano al loro posto: le licenze del software libero lo richiedono.
- **Pale Moon e i siti moderni.** È leggero proprio perché usa un motore diverso da Chrome/Firefox: alcuni siti recenti possono non funzionare bene. Per questo FreeLLMAPI usa la propria finestra e non il browser.
- **Audio** tramite ALSA (niente PulseAudio/PipeWire, per risparmiare RAM): un programma alla volta usa la scheda audio.
- **Se all'avvio dalla chiavetta compare il login testuale**, entra con `demo` / `demo`: il desktop parte subito dopo (vuol dire che l'accesso automatico non ha riconosciuto il tipo di init: segnalamelo con il `build-report.txt`).
- **Se il sistema live non trova la chiavetta**, metti `ISO_LABEL="keep"` in `config.env` (riusa l'etichetta originale di antiX) e rifai la build.
