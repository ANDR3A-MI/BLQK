#!/usr/bin/env bash
# ============================================================
#  Syntra BLQK — build della ISO a partire da antiX core x64
#  Gira su Ubuntu (runner GitHub Actions) come root:  sudo ./build.sh
# ============================================================
set -Eeuo pipefail
SYNTRA_BUILD_REV=4      # revisione degli script di build (compare nel report)
# rev.4: corretto crash della build (add_nodnsproxy ritornava codice !=0 con
#        "set -e" -> abortiva il chroot). Ora la funzione è a prova di set -e.
# rev.3: fix DNS connman (--nodnsproxy via /etc/default/connman) -> niente più
#        loopback in resolv.conf; rimosso PALEMOON_BUILD (build runner); Brave+Falkon.

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=config.env
. "$ROOT/config.env"
# impostazioni locali facoltative (non versionate), utili per prove sul proprio PC
[ -f "$ROOT/config.local.env" ] && . "$ROOT/config.local.env"
# valori passati dal workflow di GitHub (se presenti) hanno la precedenza
if [ -n "${ANTIX_VERSION_OVERRIDE:-}" ]; then
  ANTIX_MIRRORS="${ANTIX_MIRRORS//antiX-$ANTIX_VERSION/antiX-$ANTIX_VERSION_OVERRIDE}"
  ANTIX_ISO_NAME="${ANTIX_ISO_NAME//$ANTIX_VERSION/$ANTIX_VERSION_OVERRIDE}"
  ANTIX_VERSION="$ANTIX_VERSION_OVERRIDE"
fi
[ -n "${ANTIX_ISO_URL_OVERRIDE:-}" ] && ANTIX_MIRRORS="${ANTIX_ISO_URL_OVERRIDE%/*}" && ANTIX_ISO_NAME="${ANTIX_ISO_URL_OVERRIDE##*/}"
[ -n "${ANTIX_SHA256_OVERRIDE:-}" ]  && ANTIX_SHA256="$ANTIX_SHA256_OVERRIDE"
[ -n "${ARDUINO_IDE_OVERRIDE:-}" ]   && ARDUINO_IDE="$ARDUINO_IDE_OVERRIDE"

WORK="${WORK:-$ROOT/work}"
OUT="${OUT:-$ROOT/out}"
ISO_DIR="$WORK/iso"          # contenuto della ISO
ROOTFS="$WORK/rootfs"        # filesystem del sistema (squashfs scompattato)
DL="$WORK/downloads"
REPORT="$OUT/build-report.txt"
ISO_NAME="${OS_ID}-${OS_VERSION}-x64.iso"

log()  { printf '\n\033[1;35m==> %s\033[0m\n' "$*"; echo "[$(date +%T)] $*" >> "$REPORT"; }
warn() { printf '\033[1;33m[!] %s\033[0m\n' "$*"; echo "ATTENZIONE: $*" >> "$REPORT"; }
die()  { printf '\033[1;31m[X] %s\033[0m\n' "$*" >&2; exit 1; }

[ "$(id -u)" -eq 0 ] || die "Esegui come root: sudo ./build.sh"
mkdir -p "$WORK" "$OUT" "$DL"
: > "$REPORT"

# ------------------------------------------------------------
cleanup_mounts() {
  for m in dev/pts dev proc sys run; do
    mountpoint -q "$ROOTFS/$m" 2>/dev/null && umount -lf "$ROOTFS/$m" || true
  done
}
trap cleanup_mounts EXIT

# ------------------------------------------------------------
echo "Script di build: revisione $SYNTRA_BUILD_REV" >> "$REPORT"
log "1/9  Dipendenze sul sistema di build"
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq --no-install-recommends \
  squashfs-tools xorriso mtools dosfstools grub-common grub2-common \
  grub-pc-bin grub-efi-amd64-bin grub-efi-ia32-bin \
  librsvg2-bin imagemagick fonts-dejavu-core curl wget ca-certificates git \
  xz-utils zstd cpio file rsync jq openssl \
  build-essential pkg-config libx11-dev libxtst-dev libxi-dev >/dev/null

# ------------------------------------------------------------
log "2/9  Download di $ANTIX_ISO_NAME"
BASE_ISO="$DL/$ANTIX_ISO_NAME"
# scarica $2 in $1; un mirror fermo (meno di 20 kB/s per 60 s) viene abbandonato
fetch() { curl -fsSL --retry 4 --retry-delay 8 --connect-timeout 30 --speed-limit 20000 --speed-time 60 -A "Mozilla/5.0" -o "$1" "$2"; }
if [ ! -s "$BASE_ISO" ]; then
  for m in $ANTIX_MIRRORS; do
    echo "   provo: $m"
    if fetch "$BASE_ISO.part" "$m/$ANTIX_ISO_NAME" && file "$BASE_ISO.part" | grep -qiE 'ISO 9660|boot sector'; then
      mv "$BASE_ISO.part" "$BASE_ISO"; log "     scaricata da $m"; break
    fi
    rm -f "$BASE_ISO.part"
  done
fi
[ -s "$BASE_ISO" ] || die "Download della ISO antiX fallito su tutti i mirror (controlla ANTIX_VERSION in config.env)"

have="$(sha256sum "$BASE_ISO" | cut -d' ' -f1)"
case "$ANTIX_SHA256" in
  skip) warn "controllo SHA256 della ISO antiX disattivato" ;;
  auto)
    want=""
    for m in $ANTIX_MIRRORS; do   # il primo mirror è la fonte ufficiale
      if fetch "$DL/base.sha256" "$m/$ANTIX_ISO_NAME.sha256"; then
        want="$(grep -oE '[0-9a-f]{64}' "$DL/base.sha256" | head -1 || true)"
        [ -n "$want" ] && break
      fi
    done
    [ -n "$want" ] || die "File .sha256 non scaricabile: impossibile verificare la ISO (ANTIX_SHA256=skip per saltare)"
    [ "$want" = "$have" ] || die "SHA256 della ISO antiX non corrisponde ($have != $want)"
    log "     checksum SHA256 verificato: $have" ;;
  *)
    [ "$ANTIX_SHA256" = "$have" ] || die "SHA256 della ISO antiX non corrisponde ($have != $ANTIX_SHA256)"
    log "     checksum SHA256 verificato (valore fissato in config.env)" ;;
esac

# ------------------------------------------------------------
log "3/9  Estrazione ISO e filesystem"
rm -rf "$ISO_DIR" "$ROOTFS"
mkdir -p "$ISO_DIR"
xorriso -osirrox on -indev "$BASE_ISO" -extract / "$ISO_DIR" >/dev/null 2>&1
chmod -R u+w "$ISO_DIR"

BDIR="$(dirname "$(find "$ISO_DIR" -maxdepth 2 -name linuxfs -type f | head -1)")"
[ -f "$BDIR/linuxfs" ] || die "linuxfs non trovato nella ISO antiX"
BDIR_NAME="$(basename "$BDIR")"           # di solito "antiX": il live-init lo cerca qui
KERNEL="$(ls "$BDIR"/vmlinuz* 2>/dev/null | head -1)"
INITRD="$(ls "$BDIR"/initrd* 2>/dev/null | head -1)"
[ -n "$KERNEL" ] && [ -n "$INITRD" ] || die "kernel/initrd non trovati in $BDIR"

# Parametri di avvio originali (es. quiet, init=...), senza lingua/tastiera.
# Si leggono dal menu GRUB della ISO, poi da quello syslinux; i segnaposto non
# sostituiti (es. %CORE_OPTIONS%) e le variabili ($kopts) vengono scartati.
clean_args() {
  tr -s ' \t' '\n' \
    | grep -vE '^(lang|kbd|kbvar|kbopt|tz|desktop|splash|splasht|nosplash|disable|dpi|xres|vga|initrd|BOOT_IMAGE)(=.*)?$' \
    | grep -vE '^\$|%|^$' | tr '\n' ' ' | xargs
}
# conta solo la PRIMA voce di ciascun menu (quella predefinita): le altre sono
# modalità di emergenza con opzioni che non vogliamo ereditare (es. nomodeset)
first_line() { grep -hiE "$1" "${@:2}" 2>/dev/null | head -1 || true; }
ORIG_ARGS="$(first_line '^\s*linux(efi)?\s+\S*vmlinuz' "$ISO_DIR"/boot/grub/grub.cfg "$ISO_DIR"/boot/grub/*.cfg \
            | sed -E 's/^\s*linux(efi)?\s+\S+//' | clean_args || true)"
if [ -z "$ORIG_ARGS" ]; then
  ORIG_ARGS="$(first_line '^\s*append\s' "$ISO_DIR"/boot/syslinux/*.cfg "$ISO_DIR"/boot/isolinux/*.cfg \
              | sed -E 's/^\s*append\s+//I' | clean_args || true)"
fi
ORIG_ARGS="${ORIG_ARGS:-quiet}"
log "     boot dir: /$BDIR_NAME  kernel: $(basename "$KERNEL")  initrd: $(basename "$INITRD")"
log "     parametri originali: $ORIG_ARGS"

ORIG_COMP="$(unsquashfs -s "$BDIR/linuxfs" | sed -n 's/^Compression //p' | awk '{print $1}')"
ORIG_BLOCK="$(unsquashfs -s "$BDIR/linuxfs" | sed -n 's/^Block size //p' | awk '{print $1}')"
unsquashfs -q -d "$ROOTFS" "$BDIR/linuxfs"
[ -x "$ROOTFS/bin/bash" ] || [ -x "$ROOTFS/usr/bin/bash" ] || die "linuxfs estratto ma non sembra un sistema Linux"
# versione del kernel della chiavetta (deve avere i suoi moduli nel sistema)
KVER="$(file -b "$KERNEL" | grep -oE 'version [^ ]+' | head -1 | cut -d' ' -f2 || true)"
[ -n "$KVER" ] && [ -d "$ROOTFS/lib/modules/$KVER" ] || KVER="$(ls "$ROOTFS/lib/modules" | sort -V | tail -1)"
[ -n "$KVER" ] || die "Nessun modulo del kernel trovato nel sistema"
log "     kernel nel sistema: $KVER"

# ------------------------------------------------------------
log "4/9  Applicazioni: Arduino IDE e FreeLLMAPI (Brave/Falkon si installano dentro il sistema)"
APPS="$WORK/apps"; rm -rf "$APPS"; mkdir -p "$APPS"

# --- Arduino IDE ---
if [ "$ARDUINO_IDE" = "legacy" ]; then
  [ -s "$DL/arduino.tar.xz" ] || fetch "$DL/arduino.tar.xz" https://downloads.arduino.cc/arduino-1.8.19-linux64.tar.xz \
    || die "Download di Arduino IDE 1.8.19 fallito"
  # integrità: confronto con l'elenco SHA-512 pubblicato da Arduino
  if fetch "$DL/arduino.sha512" https://downloads.arduino.cc/arduino-1.8.19.sha512sum.txt \
     && grep -q 'arduino-1.8.19-linux64.tar.xz' "$DL/arduino.sha512"; then
    want="$(grep 'arduino-1.8.19-linux64.tar.xz' "$DL/arduino.sha512" | awk '{print $1}' | head -1)"
    [ "$want" = "$(sha512sum "$DL/arduino.tar.xz" | cut -d' ' -f1)" ] || die "SHA-512 di Arduino IDE non corrisponde a quello pubblicato"
    log "     Arduino IDE: checksum SHA-512 verificato"
  else
    warn "elenco dei checksum di Arduino non disponibile: archivio non verificato"
  fi
  mkdir -p "$APPS/arduino" && tar -xJf "$DL/arduino.tar.xz" -C "$APPS/arduino" --strip-components=1
  [ -x "$APPS/arduino/arduino" ] || die "Archivio di Arduino IDE non valido"
  echo legacy > "$APPS/arduino/.syntra-flavor"
  log "     Arduino IDE 1.8.19 (Java incluso)"
else
  # versione: quella indicata in config.env oppure l'ultima pubblicata
  AV="${ARDUINO2_VERSION:-latest}"
  if [ "$AV" = latest ]; then
    AV="$(curl -fsSL -o /dev/null -w '%{url_effective}' https://github.com/arduino/arduino-ide/releases/latest 2>/dev/null | sed 's#.*/tag/##' || true)"
    if ! echo "$AV" | grep -qE '^[0-9]+(\.[0-9]+)+$'; then
      AUTH=(); [ -n "${GITHUB_TOKEN:-}" ] && AUTH=(-H "Authorization: Bearer $GITHUB_TOKEN")
      AV="$(curl -fsSL "${AUTH[@]}" https://api.github.com/repos/arduino/arduino-ide/releases/latest 2>/dev/null | jq -r '.tag_name // empty' || true)"
    fi
  fi
  echo "$AV" | grep -qE '^[0-9]+(\.[0-9]+)+$' || die "Versione di Arduino IDE 2 non determinata: indica ARDUINO2_VERSION in config.env (es. 2.3.6)"
  url="https://github.com/arduino/arduino-ide/releases/download/$AV/arduino-ide_${AV}_Linux_64bit.AppImage"
  fetch "$DL/arduino.AppImage" "$url" || die "Download di Arduino IDE $AV fallito"
  chmod +x "$DL/arduino.AppImage"
  ( cd "$DL" && rm -rf squashfs-root && ./arduino.AppImage --appimage-extract >/dev/null )
  mv "$DL/squashfs-root" "$APPS/arduino"
  echo 2 > "$APPS/arduino/.syntra-flavor"
  log "     Arduino IDE: $(basename "$url")"
fi

# --- FreeLLMAPI ---
if [ "$FREELLMAPI_MODE" = "desktop" ]; then
  # App desktop ufficiale per Linux (la stessa di FreeLLMAPI.exe su Windows):
  # pacchetto .deb dalla pagina Releases, verificato con l'hash SHA-512 del
  # manifest pubblicato insieme alla release.
  if [ "$FREELLMAPI_RELEASE" = "latest" ]; then REL="$FREELLMAPI_REPO/releases/latest/download"
  else REL="$FREELLMAPI_REPO/releases/download/$FREELLMAPI_RELEASE"; fi
  fetch "$DL/freellmapi-linux.yml" "$REL/latest-linux.yml" || die "Manifest della release di FreeLLMAPI non trovato ($REL)"
  FL_DEB="$(grep -oE 'url: *[^ ]+_amd64\.deb' "$DL/freellmapi-linux.yml" | head -1 | sed 's/^url: *//')"
  FL_SHA="$(grep -A1 -F "url: $FL_DEB" "$DL/freellmapi-linux.yml" | sed -n 's/^ *sha512: *//p' | head -1)"
  [ -n "$FL_DEB" ] && [ -n "$FL_SHA" ] || die "Pacchetto .deb di FreeLLMAPI non elencato nel manifest della release"
  fetch "$APPS/freellmapi.deb" "$REL/$FL_DEB" || die "Download di $FL_DEB fallito"
  [ "$(openssl dgst -sha512 -binary "$APPS/freellmapi.deb" | base64 -w0)" = "$FL_SHA" ] || die "SHA-512 di $FL_DEB non corrisponde al manifest"
  log "     FreeLLMAPI desktop: $FL_DEB (SHA-512 verificato)"
else
  # Solo server (più leggero): compilato dai sorgenti; dashboard nel browser.
  rm -rf "$WORK/freellmapi-src"
  git clone --depth 1 --branch "$FREELLMAPI_REF" "$FREELLMAPI_REPO.git" "$WORK/freellmapi-src"
  FL_COMMIT="$(git -C "$WORK/freellmapi-src" rev-parse --short HEAD)"
  NODE_MAJOR="$(grep -oE '[0-9]+' "$WORK/freellmapi-src/.nvmrc" 2>/dev/null | head -1 || true)"; NODE_MAJOR="${NODE_MAJOR:-22}"
  NODEVER="$(curl -fsSL https://nodejs.org/dist/index.json \
            | jq -r --arg m "v$NODE_MAJOR." '[.[] | select(.version | startswith($m))][0].version')"
  [ -n "$NODEVER" ] && [ "$NODEVER" != null ] || die "Versione Node.js $NODE_MAJOR non trovata su nodejs.org"
  NODE_TAR="node-$NODEVER-linux-x64.tar.xz"
  fetch "$DL/$NODE_TAR" "https://nodejs.org/dist/$NODEVER/$NODE_TAR"
  fetch "$DL/node-SHASUMS256.txt" "https://nodejs.org/dist/$NODEVER/SHASUMS256.txt"
  ( cd "$DL" && grep " $NODE_TAR\$" node-SHASUMS256.txt | sha256sum -c - >/dev/null ) || die "Checksum di Node.js non valido"
  mkdir -p "$APPS/node" && tar -xJf "$DL/$NODE_TAR" -C "$APPS/node" --strip-components=1
  rm -rf "$APPS/node/include" "$APPS/node/share" "$APPS/node"/{CHANGELOG.md,README.md}
  log "     Node.js $NODEVER"

  # I moduli nativi (better-sqlite3, sharp) sono binari precompilati per glibc x64:
  # funzionano anche sull'Atom (richiedono al massimo SSE4.2, che Bay Trail ha).
  (
    set -e
    cd "$WORK/freellmapi-src"
    # alcune voci del lockfile puntano a un mirror npm: uso il registry ufficiale
    # (l'integrità resta garantita dagli hash "integrity" del lockfile)
    sed -i 's#https://registry.npmmirror.com/#https://registry.npmjs.org/#g' package-lock.json
    export PATH="$APPS/node/bin:$PATH" npm_config_cache="$WORK/npm-cache" \
           npm_config_fund=false npm_config_audit=false npm_config_update_notifier=false CI=1
    npm ci
    npm run build
    # a runtime servono solo le dipendenze del server
    rm -rf node_modules server/node_modules client/node_modules cli/node_modules
    npm ci --omit=dev --workspace=server
    rm -rf node_modules/@img/*musl* node_modules/@img/sharp-wasm32 node_modules/*-musl
    # stessa disposizione dell'immagine Docker ufficiale
    R="$APPS/freellmapi"; mkdir -p "$R/server" "$R/client" "$R/desktop"
    cp -a package.json package-lock.json node_modules shared LICENSE "$R/"
    cp -a server/package.json server/dist "$R/server/"
    if [ -d server/node_modules ]; then cp -a server/node_modules "$R/server/"; fi
    cp -a client/dist "$R/client/"
    cp -a desktop/package.json "$R/desktop/"
  ) > "$WORK/freellmapi-build.log" 2>&1 || { tail -40 "$WORK/freellmapi-build.log"; die "Build di FreeLLMAPI fallita"; }
  [ -f "$APPS/freellmapi/server/dist/index.js" ] || die "FreeLLMAPI: server/dist/index.js non prodotto"
  [ -f "$APPS/freellmapi/client/dist/index.html" ] || die "FreeLLMAPI: dashboard (client/dist) non prodotta"
  echo "$FL_COMMIT" > "$APPS/freellmapi/.syntra-commit"

  # prova di fumo: il server deve partire e servire la dashboard
  SMOKE="$WORK/fl-smoke"; rm -rf "$SMOKE"; mkdir -p "$SMOKE"
  ( cd "$APPS/freellmapi" && HOME="$SMOKE" PORT=39017 HOST=127.0.0.1 NODE_ENV=production FREELLMAPI_UPDATE_CHECK=off \
      ENCRYPTION_KEY="$(head -c 32 /dev/urandom | od -An -tx1 | tr -d ' \n')" FREEAPI_DB_PATH="$SMOKE/t.db" \
      exec "$APPS/node/bin/node" server/dist/index.js ) > "$SMOKE/log" 2>&1 &
  SMOKE_PID=$!; ok=0
  for _ in $(seq 40); do
    [ "$(curl -s -o /dev/null -w '%{http_code}' --noproxy '*' http://127.0.0.1:39017/ || true)" = 200 ] && { ok=1; break; }
    sleep 0.5
  done
  kill "$SMOKE_PID" 2>/dev/null || true; wait "$SMOKE_PID" 2>/dev/null || true
  [ "$ok" = 1 ] || { tail -20 "$SMOKE/log"; die "FreeLLMAPI compilato ma il server non risponde"; }
  log "     FreeLLMAPI server @ $FL_COMMIT ($(du -sh "$APPS/freellmapi" | cut -f1)) — prova di avvio superata"
fi

# ------------------------------------------------------------
log "5/9  Preparazione del chroot"
mkdir -p "$ROOTFS/opt/.syntra-apps"
cp -a "$APPS/." "$ROOTFS/opt/.syntra-apps/"

# overlay: file di configurazione, script, temi
# -K: /lib, /bin, /sbin nel sistema sono collegamenti a /usr/*: vanno seguiti, non sostituiti
rsync -rlptK "$ROOT/overlay/" "$ROOTFS/"

# grafica: sfondi e logo renderizzati in PNG
mkdir -p "$ROOTFS/usr/share/syntra/wallpapers" "$ROOTFS/usr/share/pixmaps"
# sfondo predefinito = immagine fornita (adattata a 1366x768) + copia a piena risoluzione
if [ -f "$ROOT/branding/wallpaper.jpg" ]; then
  convert "$ROOT/branding/wallpaper.jpg" -resize 1366x768^ -gravity center -extent 1366x768 -quality 90 \
          "$ROOTFS/usr/share/syntra/wallpapers/default.jpg"
  cp "$ROOT/branding/wallpaper.jpg" "$ROOTFS/usr/share/syntra/wallpapers/syntra-full.jpg"
  WALL=/usr/share/syntra/wallpapers/default.jpg
else
  rsvg-convert -w 1920 -h 1080 "$ROOT/branding/wallpaper.svg" -o "$ROOTFS/usr/share/syntra/wallpapers/default.png"
  WALL=/usr/share/syntra/wallpapers/default.png
fi
rsvg-convert -w 256 -h 256  "$ROOT/branding/logo.svg"      -o "$ROOTFS/usr/share/pixmaps/syntra-logo.png"
cp "$ROOT/branding/logo.svg" "$ROOTFS/usr/share/pixmaps/syntra-logo.svg"
for s in 16 24 32 48 64 128 256; do
  d="$ROOTFS/usr/share/icons/hicolor/${s}x${s}/apps"; mkdir -p "$d"
  rsvg-convert -w $s -h $s "$ROOT/branding/logo.svg" -o "$d/syntra-logo.png"
  rsvg-convert -w $s -h $s "$ROOT/branding/freellmapi.svg" -o "$d/syntra-freellmapi.png"
  rsvg-convert -w $s -h $s "$ROOT/branding/apps-grid.svg"  -o "$d/syntra-apps.png"
  for f in "$ROOT"/branding/icons/*.svg; do
    rsvg-convert -w $s -h $s "$f" -o "$d/$(basename "$f" .svg).png"
  done
done

mkdir -p "$ROOTFS/usr/share/syntra/status"
for f in "$ROOT"/branding/status/*.svg; do
  rsvg-convert -w 36 -h 36 "$f" -o "$ROOTFS/usr/share/syntra/status/$(basename "$f" .svg).png"
done

# variabili per il chroot
mkdir -p "$ROOTFS/etc/syntra"
cat > "$ROOTFS/etc/syntra/os.conf" <<EOF
OS_NAME="$OS_NAME"
OS_ID="$OS_ID"
OS_VERSION="$OS_VERSION"
OS_CODENAME="$OS_CODENAME"
OS_HOSTNAME="$OS_HOSTNAME"
LIVE_USER="$LIVE_USER"
LOCALE="$LOCALE"
KEYMAP="$KEYMAP"
TIMEZONE="$TIMEZONE"
BDIR_NAME="$BDIR_NAME"
EOF
cat > "$ROOTFS/root/build.env" <<EOF
KVER="$KVER"
WALL="$WALL"
SPLASH_MODE="${SPLASH_MODE:-always}"
BROWSER="${BROWSER:-brave}"
EOF
# ksuperkey: il tasto Windows da solo apre la griglia app (genera Alt+F1)
if [ -d "$ROOT/vendor/ksuperkey" ]; then
  if make -C "$ROOT/vendor/ksuperkey" >/dev/null 2>&1 && [ -x "$ROOT/vendor/ksuperkey/ksuperkey" ]; then
    install -m755 "$ROOT/vendor/ksuperkey/ksuperkey" "$ROOTFS/usr/local/bin/ksuperkey"
    log "     ksuperkey compilato (tasto Windows → griglia app)"
  else
    warn "ksuperkey non compilato: il tasto Windows da solo non aprirà la griglia (resta Alt+F1)"
  fi
fi

cp "$ROOT/scripts/chroot-setup.sh" "$ROOTFS/root/chroot-setup.sh"
chmod +x "$ROOTFS/root/chroot-setup.sh" "$ROOTFS"/usr/local/bin/* "$ROOTFS"/usr/local/sbin/*

# kernel nello /boot del sistema (serve all'installer per il sistema installato)
if ! ls "$ROOTFS"/boot/vmlinuz-* >/dev/null 2>&1; then
  mkdir -p "$ROOTFS/boot"
  cp "$KERNEL" "$ROOTFS/boot/vmlinuz-$KVER"
fi

# rete e mount per il chroot
RESOLV_BAK=""
if [ -e "$ROOTFS/etc/resolv.conf" ] || [ -L "$ROOTFS/etc/resolv.conf" ]; then
  RESOLV_BAK="$WORK/resolv.conf.bak"; cp -P "$ROOTFS/etc/resolv.conf" "$RESOLV_BAK"; rm -f "$ROOTFS/etc/resolv.conf"
fi
if [ -s /run/systemd/resolve/resolv.conf ]; then cp /run/systemd/resolve/resolv.conf "$ROOTFS/etc/resolv.conf"
else printf 'nameserver 1.1.1.1\nnameserver 8.8.8.8\n' > "$ROOTFS/etc/resolv.conf"; fi

mount --bind /dev "$ROOTFS/dev"; mount --bind /dev/pts "$ROOTFS/dev/pts"
mount -t proc proc "$ROOTFS/proc"; mount -t sysfs sys "$ROOTFS/sys"; mount -t tmpfs tmpfs "$ROOTFS/run"

# ------------------------------------------------------------
log "6/9  Personalizzazione del sistema (chroot)"
set +e
chroot "$ROOTFS" /usr/bin/env -i HOME=/root TERM=xterm PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin \
  LIVE_PASSWORD="$LIVE_PASSWORD" /bin/bash /root/chroot-setup.sh 2>&1 | tee "$OUT/chroot.log" \
  | grep --line-buffered -E '^(---- |ATTENZIONE|PACCHETTO MANCANTE|ERRORE|DETTAGLIO|DIAGNOSI|NOTA)'
CHROOT_RC="${PIPESTATUS[0]}"
set -e
if [ "$CHROOT_RC" -ne 0 ]; then
  tail -60 "$OUT/chroot.log"
  grep -E '^(ERRORE|ATTENZIONE|PACCHETTO MANCANTE|DETTAGLIO|DIAGNOSI|NOTA|autologin)' "$OUT/chroot.log" >> "$REPORT" || true
  { echo "--- ultime righe del log ---"; tail -25 "$OUT/chroot.log" | cut -c1-300; } >> "$REPORT"
  die "chroot-setup.sh fallito (log completo: out/chroot.log)"
fi
grep -E '^(ATTENZIONE|PACCHETTO MANCANTE|DETTAGLIO|DIAGNOSI|NOTA|autologin|Browser |FreeLLMAPI server)' "$OUT/chroot.log" >> "$REPORT" || true
log "     pacchetti installati: $(chroot "$ROOTFS" dpkg-query -W -f='x\n' 2>/dev/null | wc -l)  —  spazio occupato: $(du -sh --one-file-system "$ROOTFS" 2>/dev/null | cut -f1)"

cleanup_mounts
rm -f "$ROOTFS/root/chroot-setup.sh" "$ROOTFS/root/build.env" "$ROOTFS/etc/resolv.conf"
[ -n "$RESOLV_BAK" ] && cp -P "$RESOLV_BAK" "$ROOTFS/etc/resolv.conf"
rm -rf "$ROOTFS/opt/.syntra-apps"

# ------------------------------------------------------------
log "7/9  Nuovo squashfs"
rm -f "$BDIR/linuxfs"
[ "$SQUASHFS_COMP" = "auto" ] && SQUASHFS_COMP="${ORIG_COMP:-xz}"
COMP_OPTS=(-comp "$SQUASHFS_COMP")
[ -n "${ORIG_BLOCK:-}" ] && COMP_OPTS+=(-b "$ORIG_BLOCK")
[ "$SQUASHFS_COMP" = "xz" ] && COMP_OPTS+=(-Xbcj x86)
log "     compressione: $SQUASHFS_COMP (blocco ${ORIG_BLOCK:-predefinito})"
rm -rf "${ROOTFS:?}"/tmp/* "$ROOTFS"/var/tmp/*
mksquashfs "$ROOTFS" "$BDIR/linuxfs" "${COMP_OPTS[@]}" -noappend -no-progress
for f in "$BDIR"/*.md5; do
  [ -e "$f" ] || continue
  t="$BDIR/$(basename "$f" .md5)"; [ -f "$t" ] && ( cd "$BDIR" && md5sum "$(basename "$t")" > "$(basename "$f")" )
done
log "     linuxfs: $(du -h "$BDIR/linuxfs" | cut -f1)"

# ------------------------------------------------------------
log "8/9  Menu di avvio (BIOS + UEFI 64 bit + UEFI 32 bit per Bay Trail)"
# via i vecchi bootloader e la grafica antiX: li rigenera grub-mkrescue
rm -rf "${ISO_DIR:?}/boot" "$ISO_DIR/EFI" "$ISO_DIR/efi" "$ISO_DIR/isolinux" "$ISO_DIR/syslinux" "$ISO_DIR/[BOOT]"
find "$ISO_DIR" -maxdepth 1 -type f \( -iname '*.txt' -o -iname 'README*' -o -iname '*.htm*' -o -iname 'md5sum*' -o -iname '*.ico' -o -iname 'autorun*' \) -delete
# il file "version" resta (alcuni strumenti live lo leggono), ma con il nostro nome
[ -f "$ISO_DIR/version" ] && echo "$OS_NAME $OS_VERSION ($OS_CODENAME)" > "$ISO_DIR/version"
mkdir -p "$ISO_DIR/boot/grub/themes/syntra"

T="$ISO_DIR/boot/grub/themes/syntra"
rsvg-convert -w 1920 -h 1080 "$ROOT/branding/grub-bg.svg" -o "$T/background.png"
rsvg-convert -w 96 -h 96 "$ROOT/branding/logo.svg" -o "$T/logo.png"
rsvg-convert -w 32 -h 32 "$ROOT/branding/select.svg" -o "$T/select_c.png"
grub-mkfont -s 20 -o "$T/dejavu_20.pf2" /usr/share/fonts/truetype/dejavu/DejaVuSans.ttf
grub-mkfont -s 28 -o "$T/dejavu_bold_28.pf2" /usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf
grub-mkfont -s 16 -o "$T/dejavu_16.pf2" /usr/share/fonts/truetype/dejavu/DejaVuSans.ttf
sed "s|@OS_NAME@|$OS_NAME|g" "$ROOT/branding/grub-theme.txt" > "$T/theme.txt"

K="/$BDIR_NAME/$(basename "$KERNEL")"; I="/$BDIR_NAME/$(basename "$INITRD")"
# lingua nel formato breve di antiX ("it" per it_IT, "pt_BR" per pt_BR)
LANG_CODE="${LOCALE%%.*}"; LL="${LANG_CODE%%_*}"; CC="${LANG_CODE##*_}"
[ "$(echo "$LL" | tr 'a-z' 'A-Z')" = "$CC" ] && LANG_CODE="$LL"
# syntra.fw=<piattaforma>-<cpu di GRUB>: dice all'installer con quale firmware è
# partito il PC (efi-i386 sul T100T), anche se il kernel non espone /sys/firmware/efi
# avvio silenzioso: nasconde il testo del kernel così all'avvio si vede il video
QUIET_ARGS="quiet loglevel=3 vt.global_cursor_default=0 rd.systemd.show_status=0 udev.log_level=3"
LIVE_ARGS="$ORIG_ARGS $QUIET_ARGS lang=$LANG_CODE kbd=$KEYMAP tz=$TIMEZONE syntra.fw=\${grub_platform}-\${grub_cpu}"
cat > "$ISO_DIR/boot/grub/grub.cfg" <<EOF
# $OS_NAME — menu di avvio
set default=0
set timeout=10
set timeout_style=menu
search --no-floppy --set=root --file /$BDIR_NAME/linuxfs
insmod all_video
insmod gfxterm
insmod png
set gfxmode=auto
set gfxpayload=keep
terminal_output gfxterm
loadfont (\$root)/boot/grub/themes/syntra/dejavu_20.pf2
loadfont (\$root)/boot/grub/themes/syntra/dejavu_bold_28.pf2
loadfont (\$root)/boot/grub/themes/syntra/dejavu_16.pf2
set theme=(\$root)/boot/grub/themes/syntra/theme.txt
export theme

menuentry "Avvia $OS_NAME (Live)" --class syntra {
  linux $K $LIVE_ARGS
  initrd $I
}
menuentry "Installa $OS_NAME sul disco" --class install {
  linux $K $LIVE_ARGS syntra.install
  initrd $I
}
menuentry "Live — modalità compatibilità (grafica di base)" --class syntra {
  linux $K $LIVE_ARGS nomodeset intel_idle.max_cstate=1
  initrd $I
}
menuentry "Live — solo terminale" --class syntra {
  linux $K $LIVE_ARGS syntra.nox
  initrd $I
}
if [ "\$grub_platform" = "efi" ]; then
  menuentry "Impostazioni firmware UEFI" --class settings { fwsetup }
fi
menuentry "Riavvia" --class restart { reboot }
menuentry "Spegni" --class shutdown { halt }
EOF
# copia per chi apre la ISO come file (Ventoy, ecc.)
cp "$ISO_DIR/boot/grub/grub.cfg" "$ISO_DIR/boot/grub/loopback.cfg"

# Loader EFI anche come file dentro la ISO (/efi/boot): così la chiavetta parte
# pure se è stata preparata copiando i file su FAT32 (Rufus "modalità ISO").
# Sono GRUB autonomi che cercano la chiavetta tramite il file /$BDIR_NAME/linuxfs.
cat > "$WORK/grub-embed.cfg" <<EOF
search --no-floppy --set=root --file /$BDIR_NAME/linuxfs
configfile (\$root)/boot/grub/grub.cfg
EOF
mkdir -p "$WORK/efi-files"
for t in i386-efi:bootia32.efi x86_64-efi:bootx64.efi; do
  grub-mkstandalone -O "${t%%:*}" -o "$WORK/efi-files/${t##*:}" --locales="" --themes="" --fonts="" \
    "boot/grub/grub.cfg=$WORK/grub-embed.cfg" || die "grub-mkstandalone ${t%%:*} fallito"
done

# ------------------------------------------------------------
log "9/9  Creazione ISO ibrida"
if [ "$ISO_LABEL" = "keep" ]; then
  ISO_LABEL="$(xorriso -indev "$BASE_ISO" -pvd_info 2>/dev/null | sed -n "s/^Volume Id *: *//p" | head -1)"
  log "     etichetta originale mantenuta: $ISO_LABEL"
fi
rm -f "$OUT/$ISO_NAME"
# grub-mkrescue crea: avvio BIOS, partizione EFI (efi.img) con i loader a 32 e 64 bit
# e la copia /efi/boot nell'albero, che sostituiamo con i nostri loader autonomi.
grub-mkrescue -o "$OUT/$ISO_NAME" "$ISO_DIR" \
  --modules="part_gpt part_msdos fat iso9660 ext2 search search_fs_file all_video gfxterm png font" \
  -- -volid "$ISO_LABEL" \
     -map "$WORK/efi-files/bootia32.efi" /efi/boot/bootia32.efi \
     -map "$WORK/efi-files/bootx64.efi"  /efi/boot/bootx64.efi > "$WORK/mkrescue.log" 2>&1 \
  || { tail -20 "$WORK/mkrescue.log"; die "grub-mkrescue fallito"; }
grep -vE 'UPDATE|^$' "$WORK/mkrescue.log" | tail -4 || true
[ -s "$OUT/$ISO_NAME" ] || die "grub-mkrescue non ha prodotto la ISO"

# verifica: devono esserci entrambi i loader EFI (x64 e ia32 per il T100T)
EFI_IMG="$(xorriso -indev "$OUT/$ISO_NAME" -report_el_torito plain 2>/dev/null | grep -c 'UEFI' || true)"
mkdir -p "$WORK/efichk"; rm -rf "$WORK/efichk"/*
xorriso -osirrox on -indev "$OUT/$ISO_NAME" -extract /efi.img "$WORK/efichk/efi.img" >/dev/null 2>&1 || true
if [ -s "$WORK/efichk/efi.img" ]; then
  EFI_LIST="$(mdir -b -i "$WORK/efichk/efi.img" ::/efi/boot 2>/dev/null | tr '\n' ' ' || true)"
  if echo "$EFI_LIST" | grep -qi bootia32; then log "     OK: bootia32.efi presente (UEFI 32 bit del T100T)"
  else warn "bootia32.efi NON trovato nella partizione EFI della ISO ($EFI_LIST)"; fi
else
  log "     immagini El Torito UEFI trovate: $EFI_IMG"
fi

xorriso -indev "$OUT/$ISO_NAME" -find /efi/boot -name 'boot*.efi' 2>/dev/null | grep -qi bootia32 \
  || warn "/efi/boot/bootia32.efi non presente nell'albero della ISO"
ISO_BYTES="$(stat -c %s "$OUT/$ISO_NAME")"
[ "$ISO_BYTES" -lt 2147483648 ] || warn "ISO più grande di 2 GB: l'upload come artefatto GitHub funziona, come allegato di una Release no"

( cd "$OUT" && sha256sum "$ISO_NAME" > "$ISO_NAME.sha256" )
log "FATTO: out/$ISO_NAME ($(du -h "$OUT/$ISO_NAME" | cut -f1))"
